#!/bin/bash
sudo chown -R $(whoami) /home/ws
echo 'export PYTHONPATH=$PYTHONPATH:/home/ws/source' >> ~/.bashrc

# The pure-Python core is imported as `core.*` from the repo root
grep -qxF 'export PYTHONPATH=$PYTHONPATH:/home/ws' ~/.bashrc || \
    echo 'export PYTHONPATH=$PYTHONPATH:/home/ws' >> ~/.bashrc

# Install all ROS 2 workspace dependencies once
if [ ! -f /home/ws/.rosdep_installed ]; then
    rosdep update
    rosdep install --from-paths /home/ws/ros2_ws/src --ignore-src -r -y
    touch /home/ws/.rosdep_installed
fi

