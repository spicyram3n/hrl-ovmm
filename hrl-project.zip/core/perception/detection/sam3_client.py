"""
sam3_client.py
--------------
Thin HTTP client for the SAM3 docker server (docker/sam3).

SAM3 needs Python >= 3.12 / PyTorch >= 2.7 / CUDA >= 12.6, so it cannot run
inside the ROS 2 Humble devcontainer (Python 3.10). It runs in its own
container on port 5005 and we talk to it over REST, same pattern as the
OpenMask3D and AnyGrasp servers.

Usage (step 5 of the demo: robot observes a location and tries to detect
the target object in the head camera RGB image):

    from core.perception.detection.sam3_client import Sam3Client
    client = Sam3Client()
    det = client.detect(rgb_image, "red cup")
    if det.found:
        mask = det.best_mask()   # (H, W) bool, lift to 3D with the depth image
"""

from __future__ import annotations

import io
import json
import zipfile
from dataclasses import dataclass, field

import cv2
import numpy as np
import requests


@dataclass
class Sam3Detection:
    prompt: str
    masks: np.ndarray = field(default_factory=lambda: np.zeros((0, 0, 0), dtype=bool))
    boxes: np.ndarray = field(default_factory=lambda: np.zeros((0, 4)))
    scores: np.ndarray = field(default_factory=lambda: np.zeros((0,)))

    @property
    def found(self) -> bool:
        return self.masks.shape[0] > 0

    def best(self) -> int:
        return int(np.argmax(self.scores))

    def best_mask(self) -> np.ndarray:
        return self.masks[self.best()]

    def best_box(self) -> np.ndarray:
        return self.boxes[self.best()]


class Sam3Client:
    def __init__(self, host: str = "localhost", port: int = 5005, timeout: int = 120):
        self.url = f"http://{host}:{port}/sam3/predict"
        self.timeout = timeout

    def detect(self, image_bgr: np.ndarray, prompt: str, conf: float = 0.5) -> Sam3Detection:
        """image_bgr: OpenCV image (as delivered by cv_bridge)."""
        ok, encoded = cv2.imencode(".jpg", image_bgr)
        if not ok:
            raise ValueError("Could not encode image")

        response = requests.post(
            self.url,
            files={"image": ("frame.jpg", encoded.tobytes(), "image/jpeg")},
            params={"prompt": prompt, "conf": conf},
            timeout=self.timeout,
        )
        if response.status_code != 200:
            raise RuntimeError(f"SAM3 server error {response.status_code}: {response.text}")

        det = Sam3Detection(prompt=prompt)
        with zipfile.ZipFile(io.BytesIO(response.content)) as zf:
            det.masks = np.load(io.BytesIO(zf.read("masks.npy")))
            det.boxes = np.load(io.BytesIO(zf.read("boxes.npy")))
            det.scores = np.load(io.BytesIO(zf.read("scores.npy")))
            meta = json.loads(zf.read("meta.json"))
        print(f"[sam3] '{prompt}': {meta['num_instances']} instance(s)")
        return det


def mask_to_pointcloud(
    mask: np.ndarray,
    depth: np.ndarray,
    intrinsics: np.ndarray,
    depth_scale: float = 1000.0,
):
    """
    Lift a SAM3 mask + aligned depth image to a 3D point cloud in the
    camera frame (step 6: build the RGBD point cloud of the object).

    mask:       (H, W) bool
    depth:      (H, W) uint16/float, aligned to the RGB image
    intrinsics: 3x3 camera matrix K
    """
    import open3d as o3d

    fx, fy = intrinsics[0, 0], intrinsics[1, 1]
    cx, cy = intrinsics[0, 2], intrinsics[1, 2]

    v, u = np.where(mask)
    z = depth[v, u].astype(np.float64) / depth_scale
    valid = z > 0
    u, v, z = u[valid], v[valid], z[valid]

    x = (u - cx) * z / fx
    y = (v - cy) * z / fy
    pts = np.stack([x, y, z], axis=1)

    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(pts)
    return pcd
