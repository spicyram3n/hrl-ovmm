"""
SAM3 REST server.

Mirrors the request/response pattern of the OpenMask3D server in
stretch-compose: multipart file upload in, files (npz + json) zipped out.

Endpoint:
    POST /sam3/predict
        files:  image  (jpg/png)
        params: prompt (text concept, e.g. "red cup")
                conf   (optional float threshold, default 0.5)

Response: zip containing
    masks.npy   (N, H, W) bool
    boxes.npy   (N, 4) xyxy float
    scores.npy  (N,) float
    meta.json   {"prompt": ..., "num_instances": N}
"""

import io
import json
import os
import zipfile

import numpy as np
import torch
from flask import Flask, request, send_file
from PIL import Image

app = Flask(__name__)

MODEL = None
PROCESSOR = None


def get_model():
    """Lazy-load so the container starts fast and fails loudly on first call."""
    global MODEL, PROCESSOR
    if MODEL is None:
        from sam3.model_builder import build_sam3_image_model
        from sam3.model.sam3_image_processor import Sam3Processor

        token = os.environ.get("HF_TOKEN") or None
        if token:
            from huggingface_hub import login
            login(token=token)

        MODEL = build_sam3_image_model()  # downloads facebook/sam3 checkpoint
        PROCESSOR = Sam3Processor(MODEL)
    return MODEL, PROCESSOR


@app.route("/sam3/predict", methods=["POST"])
def predict():
    if "image" not in request.files:
        return json.dumps({"error": "no image file provided"}), 400
    prompt = request.args.get("prompt", "")
    if not prompt:
        return json.dumps({"error": "no prompt provided"}), 400
    conf = float(request.args.get("conf", 0.5))

    image = Image.open(request.files["image"].stream).convert("RGB")

    _, processor = get_model()
    with torch.inference_mode():
        state = processor.set_image(image)
        output = processor.set_text_prompt(state=state, prompt=prompt)

    masks = output["masks"]      # (N, H, W)
    boxes = output["boxes"]      # (N, 4) xyxy
    scores = output["scores"]    # (N,)

    masks = masks.cpu().numpy().astype(bool) if torch.is_tensor(masks) else np.asarray(masks, dtype=bool)
    boxes = boxes.cpu().numpy() if torch.is_tensor(boxes) else np.asarray(boxes)
    scores = scores.cpu().numpy() if torch.is_tensor(scores) else np.asarray(scores)

    keep = scores >= conf
    masks, boxes, scores = masks[keep], boxes[keep], scores[keep]

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, arr in [("masks.npy", masks), ("boxes.npy", boxes), ("scores.npy", scores)]:
            arr_buf = io.BytesIO()
            np.save(arr_buf, arr)
            zf.writestr(name, arr_buf.getvalue())
        zf.writestr("meta.json", json.dumps({"prompt": prompt, "num_instances": int(masks.shape[0])}))
    buf.seek(0)
    return send_file(buf, mimetype="application/zip")


@app.route("/healthz", methods=["GET"])
def healthz():
    return json.dumps({"status": "ok"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5005)
