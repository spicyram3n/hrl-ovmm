#!/bin/bash
# Run Mask3D segmentation on a workspace folder.
#
# Run this ON THE HOST, NOT inside the devcontainer: it needs the `docker`
# CLI (the devcontainer doesn't have docker-outside-of-docker set up), and
# the mask3d container mounts the host's /home so host paths apply.
#
#   bash docker/mask3d/run_mask3d.sh [workspace_folder] [mask3d_repo]
#
# workspace_folder defaults to /home/comrade/Desktop/data_hrl, the host path
# that's bind-mounted to /home/ws/data inside the devcontainer (where the
# scan data, e.g. scene.ply, already lives).
# Optional second arg: path to the Mask3D repo (default: <repo>/models/Mask3D)
set -e

WORKSPACE="${1:-/home/comrade/Desktop/data_hrl}"
MASK3D_REPO="${2:-$(pwd)/models/Mask3D}"

if [ ! -f "$MASK3D_REPO/checkpoints/mask3d_scannet200_demo.ckpt" ]; then
    echo "ERROR: checkpoint missing. Run docker/mask3d/setup_mask3d.sh first."
    exit 1
fi

# Mask3D expects a file named mesh.ply in the workspace. If only scene.ply
# is present (the raw scan), make a temporary mesh.ply for the run and
# remove it afterwards.
CLEANUP_MESH=""
if [ ! -f "$WORKSPACE/mesh.ply" ]; then
    if [ -f "$WORKSPACE/scene.ply" ]; then
        echo "No mesh.ply found, using a temporary copy of scene.ply as input."
        cp "$WORKSPACE/scene.ply" "$WORKSPACE/mesh.ply"
        CLEANUP_MESH="$WORKSPACE/mesh.ply"
    else
        echo "ERROR: neither $WORKSPACE/mesh.ply nor $WORKSPACE/scene.ply found in $WORKSPACE."
        echo "Run docker/mask3d/prepare_workspace.py first, or point at a workspace with a scan."
        exit 1
    fi
fi
trap '[ -n "$CLEANUP_MESH" ] && rm -f "$CLEANUP_MESH"' EXIT

docker run --gpus all -it --rm \
    --entrypoint /bin/bash \
    -v /home:/home \
    -w "$MASK3D_REPO" \
    rupalsaxena/mask3d_docker:latest \
    python3 mask3d.py --seed 42 --workspace "$WORKSPACE"

echo "Done. Outputs in $WORKSPACE: predictions.txt, pred_mask/, mesh_labeled.ply"
